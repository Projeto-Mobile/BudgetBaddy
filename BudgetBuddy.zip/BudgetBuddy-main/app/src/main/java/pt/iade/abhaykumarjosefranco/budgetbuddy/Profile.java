package pt.iade.abhaykumarjosefranco.budgetbuddy;

import android.app.Activity;

public class Profile extends Activity {
}

