package pt.iade.BudgetBuddy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BudgetBuddyApplicationTests {

	@Test
	void contextLoads() {
	}

}
