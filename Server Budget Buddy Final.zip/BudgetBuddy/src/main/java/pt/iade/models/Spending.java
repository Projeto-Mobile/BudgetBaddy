package pt.iade.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.JoinColumn;





@Entity
@Table(name = "spending")
public class Spending {
    @Id
    @Column(name = "spend_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name = "spend_value")
    private int spendValue;
    @Column(name = "spend_date")
    private String date;
    @Column(name = "spend_name")
    private String name;
    @ManyToOne
    @JoinColumn(name = "spend_cat_id")
    private Category category;
    @ManyToOne
    @JoinColumn(name = "spend_user_id")
    private User user;
    
    


    public Spending(int id, int spendValue, String date, String name, Category category, User user) {
        this.id = id;
        this.spendValue = spendValue;
        this.date = date;
        this.name = name;
        this.category = category;
        this.user = user;
    }

    

    public Spending() {

    }
    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public String getDate() {
        return date;
    }
    public int getSpendValue() {
        return spendValue;
    }
    public void setId(int id) {
        this.id = id;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public void setSpendValue(int spendValue) {
        this.spendValue = spendValue;
    }
    public Category getCategory() {
        return category;
    }
    public User getUser() {
        return user;
    }
    public String getCategoryName() {
        return category.getName();
    }
    public String getUserName() {
        return user.getName();
    }
    public void setCategoryName(String categoryName) {
        this.category.setName(categoryName);
    }
    public void setUserName(String userName) {
        this.user.setName(userName);
    }
    public void setCategory(Category category) {
        this.category = category;
    }
    public void setUser(User user) {
        this.user = user;
    }
    


        

}
