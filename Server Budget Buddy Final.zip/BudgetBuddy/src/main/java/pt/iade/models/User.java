package pt.iade.models;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;



@Entity
@Table(name = "userapp")
public class User{
    @Id
    @Column(name = "user_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name = "user_name")
    private String name;
    @Column(name = "user_email")
    private String email;
    @Column(name = "user_password")
    private String password;
    @Column(name = "user_secret")
    private String secret;

    public User(int id, String name, String email, String password, String secret) {
        this.id = id;
        this.name = name;
        this.email= email;
        this.password = password;
        this.secret = secret;
    }
    
   
    
    public User() {
        
    }
    public class Login{
        private String email;
        private String password;
        public Login(String email, String password) {
            this.email = email;
            this.password = password;
        }
        public String getEmail() {
            return email;
        }
        public String getPassword() {
            return password;
        }
    }
    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public String getEmail(){
        return email;
    }  
    public String getPassword(){
        return password;
    }
    public String getSecret(){
        return secret;
    }
    public String createSecret(){
        secret = randomString(8);
        return secret;
    }
    public void setId(int id) {
        this.id = id;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public void setPassword(String password){
        this.password = password;
    }
    public void setSecret(String secret){
        this.secret = secret;
    }
    public String randomString(int n) {
            String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz"; 
            StringBuilder secret = new StringBuilder(n); 
            for (int i = 0; i < n; i++) { 
                int index = (int)(AlphaNumericString.length() * Math.random()); 
                secret.append(AlphaNumericString.charAt(index)); 
            } 
        return secret.toString();
    }
    




    
}

    