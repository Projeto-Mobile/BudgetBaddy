package pt.iade.controllers;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;




import org.springframework.beans.factory.annotation.Autowired;

//

import pt.iade.models.*;
import pt.iade.models.repositories.BudgetRepository;
import pt.iade.models.responses.Response;
@RestController
@RequestMapping(path = "/api/budgets")

public class BudgetController {
    @Autowired 
    private BudgetRepository BudgetRepository;
    //private Logger logger = LoggerFactory.getLogger(BudgetController.class);

    @Autowired
    @GetMapping(path = "/list", produces = MediaType.APPLICATION_JSON_VALUE)
    private Iterable<Budget> ListBudgetController () {
        Iterable<Budget> budget = BudgetRepository.findAll();
        return budget;
    }
    @GetMapping(path = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    private Budget getBudgetController (@PathVariable int id) {
        Budget budget = BudgetRepository.findById(id).get();
        return budget;
    }
    

    @DeleteMapping(path = "{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    private Response deleteBudgetResponse(@PathVariable int id) {
        Budget budget = BudgetRepository.findById(id).get();
        BudgetRepository.delete(budget);
        return new Response(budget.getId() + " was deleted.", null);
    }

    @PostMapping(path = "/add", produces = MediaType.APPLICATION_JSON_VALUE)
    private Budget postBudgetController (@RequestBody Budget budget) {
        Budget b;
        if(budget.getId() == 0){
            b = new Budget();
            b.setName(budget.getName());
            b.setDateStart(budget.getDateStart());
            b.setDateEnd(budget.getDateEnd());
            b.setBudgetValue(budget.getBudgetValue());
            b.setCategory(budget.getCategory());
            b.setUser(budget.getUser());
            //b.setOwnerId(budget.getOwnerId());
            
           
            

        } else {
            b = budget;
        }
        Budget returnedBudget = BudgetRepository.save(b);
        return returnedBudget;
    }

    
}